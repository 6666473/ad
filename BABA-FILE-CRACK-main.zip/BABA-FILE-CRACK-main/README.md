

<p><img align="left" src="https://github-readme-stats.vercel.app/api/top-langs?username=TECH-BABA&show_icons=true&locale=en&layout=compact" alt="TECH-BABA" /></p>

<p>&nbsp;<img align="center" src="https://github-readme-stats.vercel.app/api?username=TECH-BABA&show_icons=true&locale=en" alt="TECH-BABA" /></p>
<p align="center">
<a href="https://m.facebook.com/H4CK3R.BABA"><img title="Facebook" src="https://img.shields.io/badge/Facebook-lightgrey?style=for-the-badge&logo=facebook"></a>
<a href="https://github.com/TECH-BABA"><img title="Github" src="https://img.shields.io/badge/Github-TECH-BABA--yallow?style=for-the-badge&logo=github"></a>
